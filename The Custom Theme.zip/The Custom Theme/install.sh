sudo mkdir /boot/grub/themes
cp -a the-custom-theme /boot/grub/themes
grep "GRUB_THEME=" /etc/default/grub 2>&1 >/dev/null && sed -i '/GRUB_THEME=/d' /etc/default/grub
echo "GRUB_THEME="/boot/grub/themes/the-custom-theme/theme.txt"" >> /etc/default/grub
sudo update-grub
